var i=1;
var arrNum = new Array("a", "kim", "Lee", "Back");

function add_row() {
	var myTbody=document.getElementById('myTable');
	var row=myTbody.insertRow(myTbody.rows.length);
	var cell1=row.insertCell(0);
	var cell2=row.insertCell(1);
	cell1.innerHTML=i;
	cell2.innerHTML=arrNum[i]
	i++;
}